
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // ==============================
    // DATABASE CONNECTION
    // ==============================

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/smartattendance"
            + "?useSSL=false"
            + "&allowPublicKeyRetrieval=true"
            + "&serverTimezone=UTC";

    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root123";

    // ==============================
    // LOGIN
    // ==============================

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null) {
            username = "";
        }

        if (password == null) {
            password = "";
        }

        username = username.trim();
        password = password.trim();

        // ==============================
        // VALIDATION
        // ==============================

        if (username.isEmpty() || password.isEmpty()) {

            showError(response,
                    "Please enter your Gmail ID and password.");

            return;
        }

        // ==============================
        // SQL
        // ==============================

        String sql =
                "SELECT id, username, password, role "
                + "FROM users "
                + "WHERE LOWER(TRIM(username)) = LOWER(?)";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            try (
                Connection con = DriverManager.getConnection(
                        DB_URL,
                        DB_USER,
                        DB_PASSWORD
                );

                PreparedStatement ps = con.prepareStatement(sql)
            ) {

                ps.setString(1, username);

                try (ResultSet rs = ps.executeQuery()) {

                    // ==============================
                    // USER FOUND
                    // ==============================

                    if (!rs.next()) {

                        showError(response,
                                "Invalid Gmail ID or password.");

                        return;
                    }

                    int userId = rs.getInt("id");

                    String dbUsername =
                            rs.getString("username");

                    String dbPassword =
                            rs.getString("password");

                    String dbRole =
                            rs.getString("role");

                    // ==============================
                    // PASSWORD CHECK
                    // ==============================

                    boolean passwordCorrect =
                            dbPassword != null
                            && dbPassword.equals(password);

                    if (!passwordCorrect) {

                        showError(response,
                                "Invalid Gmail ID or password.");

                        return;
                    }

                    // ==============================
                    // ROLE VALIDATION
                    // ==============================

                    if (dbRole == null ||
                            dbRole.trim().isEmpty()) {

                        showError(response,
                                "User role is missing in database.");

                        return;
                    }

                    String role =
                            dbRole.trim().toLowerCase();

                    // ==============================
                    // SESSION
                    // ==============================

                    HttpSession session =
                            request.getSession(true);

                    // Prevent session fixation
                    request.changeSessionId();

                    session.setAttribute(
                            "userId",
                            userId
                    );

                    session.setAttribute(
                            "username",
                            dbUsername
                    );

                    session.setAttribute(
                            "databaseRole",
                            role
                    );

                    session.setAttribute(
                            "passwordVerified",
                            true
                    );

                    // ==============================
                    // ROLE-BASED REDIRECT
                    // ==============================

                    String dashboard = null;

                    switch (role) {

                        case "admin":

                            dashboard = "admin.html";

                            break;

                        case "faculty":

                            dashboard = "faculty.html";

                            break;

                        case "student":

                            dashboard = "student.html";

                            break;

                        default:

                            session.invalidate();

                            showError(response,
                                    "Invalid user role in database.");

                            return;
                    }

                    // ==============================
                    // REDIRECT TO DASHBOARD
                    // ==============================

                    response.sendRedirect(
                            request.getContextPath()
                            + "/"
                            + dashboard
                    );
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            showError(response,
                    "Database connection error. "
                    + "Please check your MySQL configuration.");
        }
    }

    // ==============================
    // ERROR PAGE
    // ==============================

    private void showError(
            HttpServletResponse response,
            String message)
            throws IOException {

        response.setContentType(
                "text/html;charset=UTF-8"
        );

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");

        out.println("<html lang='en'>");

        out.println("<head>");

        out.println("<meta charset='UTF-8'>");

        out.println(
                "<meta name='viewport' "
                + "content='width=device-width, "
                + "initial-scale=1.0'>"
        );

        out.println("<title>SmartAttend - Login Failed</title>");

        out.println("<style>");

        out.println(
                "*{"
                + "box-sizing:border-box;"
                + "margin:0;"
                + "padding:0;"
                + "}"
        );

        out.println(
                "body{"
                + "min-height:100vh;"
                + "font-family:Arial,Helvetica,sans-serif;"
                + "background:linear-gradient(135deg,#eef4ff,#f4f0ff);"
                + "display:flex;"
                + "align-items:center;"
                + "justify-content:center;"
                + "padding:20px;"
                + "}"
        );

        out.println(
                ".box{"
                + "width:100%;"
                + "max-width:500px;"
                + "background:#ffffff;"
                + "border-radius:20px;"
                + "padding:45px 35px;"
                + "text-align:center;"
                + "box-shadow:0 20px 50px rgba(15,23,42,.12);"
                + "}"
        );

        out.println(
                ".icon{"
                + "font-size:65px;"
                + "margin-bottom:15px;"
                + "}"
        );

        out.println(
                "h1{"
                + "color:#0f172a;"
                + "font-size:30px;"
                + "margin-bottom:15px;"
                + "}"
        );

        out.println(
                "p{"
                + "color:#64748b;"
                + "font-size:16px;"
                + "line-height:1.6;"
                + "margin-bottom:25px;"
                + "}"
        );

        out.println(
                ".button{"
                + "display:inline-block;"
                + "padding:13px 28px;"
                + "background:#2563eb;"
                + "color:white;"
                + "text-decoration:none;"
                + "border-radius:10px;"
                + "font-weight:bold;"
                + "transition:.2s;"
                + "}"
        );

        out.println(
                ".button:hover{"
                + "background:#1d4ed8;"
                + "}"
        );

        out.println("</style>");

        out.println("</head>");

        out.println("<body>");

        out.println("<div class='box'>");

        out.println("<div class='icon'>⚠️</div>");

        out.println("<h1>Login Failed</h1>");

        out.println(
                "<p>"
                + escapeHtml(message)
                + "</p>"
        );

        out.println(
                "<a class='button' href='login.html'>"
                + "← Try Again"
                + "</a>"
        );

        out.println("</div>");

        out.println("</body>");

        out.println("</html>");
    }

    // ==============================
    // HTML ESCAPE
    // ==============================

    private String escapeHtml(String text) {

        if (text == null) {
            return "";
        }

        return text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}