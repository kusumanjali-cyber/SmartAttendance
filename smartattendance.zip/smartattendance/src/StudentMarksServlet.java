import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/StudentMarksServlet")
public class StudentMarksServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/smartattendance"
            + "?useSSL=false"
            + "&allowPublicKeyRetrieval=true"
            + "&serverTimezone=UTC";

    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root123";

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);

        // Check login
        if (session == null ||
            session.getAttribute("userId") == null ||
            session.getAttribute("passwordVerified") == null) {

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

            out.print(
                "{\"success\":false,\"message\":\"Please login first\"}"
            );

            return;
        }

        String username =
                String.valueOf(session.getAttribute("username"));

        String sql =
                "SELECT " +
                "m.id, " +
                "m.marks, " +
                "m.exam_type, " +
                "s.subject_name " +
                "FROM marks m " +
                "INNER JOIN students st " +
                "ON m.student_id = st.id " +
                "INNER JOIN subjects s " +
                "ON m.subject_id = s.id " +
                "WHERE LOWER(TRIM(st.email)) = LOWER(TRIM(?)) " +
                "ORDER BY s.subject_name, m.exam_type";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection connection =
                        DriverManager.getConnection(
                                DB_URL,
                                DB_USER,
                                DB_PASSWORD);

                 PreparedStatement statement =
                        connection.prepareStatement(sql)) {

                statement.setString(1, username);

                try (ResultSet rs = statement.executeQuery()) {

                    StringBuilder json =
                            new StringBuilder();

                    json.append("{");
                    json.append("\"success\":true,");
                    json.append("\"marks\":[");

                    boolean first = true;

                    while (rs.next()) {

                        if (!first) {
                            json.append(",");
                        }

                        first = false;

                        json.append("{");

                        json.append("\"id\":")
                            .append(rs.getInt("id"))
                            .append(",");

                        json.append("\"subject\":\"")
                            .append(escapeJson(
                                rs.getString("subject_name")))
                            .append("\",");

                        json.append("\"examType\":\"")
                            .append(escapeJson(
                                rs.getString("exam_type")))
                            .append("\",");

                        json.append("\"marks\":")
                            .append(rs.getDouble("marks"));

                        json.append("}");
                    }

                    json.append("]");
                    json.append("}");

                    out.print(json.toString());
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            out.print(
                "{\"success\":false," +
                "\"message\":\"Unable to load marks\"}"
            );
        }
    }


    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}