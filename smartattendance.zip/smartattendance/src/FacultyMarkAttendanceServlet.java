import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FacultyMarkAttendanceServlet")
public class FacultyMarkAttendanceServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/smartattendance"
            + "?useSSL=false"
            + "&allowPublicKeyRetrieval=true"
            + "&serverTimezone=UTC";

    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root123";


    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();


        /* =========================
           LOGIN CHECK
           ========================= */

        HttpSession session = request.getSession(false);

        if (session == null
                || session.getAttribute("userId") == null
                || session.getAttribute("passwordVerified") == null) {

            response.setStatus(
                    HttpServletResponse.SC_UNAUTHORIZED
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"Please login first\"}"
            );

            return;
        }


        /* =========================
           GET PARAMETERS
           ========================= */

        String studentIdText =
                request.getParameter("studentId");

        String subjectIdText =
                request.getParameter("subjectId");

        String attendanceDate =
                request.getParameter("attendanceDate");

        String status =
                request.getParameter("status");


        /* =========================
           REQUIRED FIELD CHECK
           ========================= */

        if (isEmpty(studentIdText)
                || isEmpty(subjectIdText)
                || isEmpty(attendanceDate)
                || isEmpty(status)) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"All attendance fields are required\"}"
            );

            return;
        }


        /* =========================
           ID VALIDATION
           ========================= */

        int studentId;
        int subjectId;

        try {

            studentId =
                    Integer.parseInt(
                            studentIdText.trim()
                    );

            subjectId =
                    Integer.parseInt(
                            subjectIdText.trim()
                    );

            if (studentId <= 0 || subjectId <= 0) {
                throw new NumberFormatException();
            }

        } catch (NumberFormatException e) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"Invalid student or subject ID\"}"
            );

            return;
        }


        /* =========================
           DATE VALIDATION
           ========================= */

        attendanceDate =
                attendanceDate.trim();

        try {

            LocalDate.parse(attendanceDate);

        } catch (DateTimeParseException e) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"Invalid attendance date. Use YYYY-MM-DD\"}"
            );

            return;
        }


        /* =========================
           STATUS VALIDATION
           ========================= */

        status =
                status.trim().toUpperCase();

        if (!status.equals("PRESENT")
                && !status.equals("ABSENT")) {

            response.setStatus(
                    HttpServletResponse.SC_BAD_REQUEST
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"Attendance status must be PRESENT or ABSENT\"}"
            );

            return;
        }


        /* =========================
           ATTENDANCE VALUES
           ========================= */

        int totalClasses = 1;

        int attendedClasses =
                status.equals("PRESENT") ? 1 : 0;


        /* =========================
           SQL
           ========================= */

        String checkSql =
                "SELECT id "
                + "FROM attendance_records "
                + "WHERE student_id = ? "
                + "AND subject_id = ? "
                + "AND attendance_date = ?";


        String updateSql =
                "UPDATE attendance_records "
                + "SET total_classes = ?, "
                + "attended_classes = ? "
                + "WHERE student_id = ? "
                + "AND subject_id = ? "
                + "AND attendance_date = ?";


        String insertSql =
                "INSERT INTO attendance_records "
                + "(student_id, subject_id, total_classes, "
                + "attended_classes, attendance_date) "
                + "VALUES (?, ?, ?, ?, ?)";


        /* =========================
           DATABASE
           ========================= */

        try {

            Class.forName(
                    "com.mysql.cj.jdbc.Driver"
            );


            try (
                Connection con =
                        DriverManager.getConnection(
                                DB_URL,
                                DB_USER,
                                DB_PASSWORD
                        )
            ) {

                boolean exists = false;


                /* =========================
                   CHECK EXISTING RECORD
                   ========================= */

                try (
                    PreparedStatement checkPs =
                            con.prepareStatement(checkSql)
                ) {

                    checkPs.setInt(
                            1,
                            studentId
                    );

                    checkPs.setInt(
                            2,
                            subjectId
                    );

                    checkPs.setString(
                            3,
                            attendanceDate
                    );


                    try (
                        ResultSet rs =
                                checkPs.executeQuery()
                    ) {

                        if (rs.next()) {
                            exists = true;
                        }
                    }
                }


                /* =========================
                   UPDATE EXISTING RECORD
                   ========================= */

                if (exists) {

                    try (
                        PreparedStatement updatePs =
                                con.prepareStatement(updateSql)
                    ) {

                        updatePs.setInt(
                                1,
                                totalClasses
                        );

                        updatePs.setInt(
                                2,
                                attendedClasses
                        );

                        updatePs.setInt(
                                3,
                                studentId
                        );

                        updatePs.setInt(
                                4,
                                subjectId
                        );

                        updatePs.setString(
                                5,
                                attendanceDate
                        );

                        updatePs.executeUpdate();
                    }


                    out.print(
                            "{\"success\":true,"
                            + "\"message\":\"Attendance updated successfully\","
                            + "\"status\":\""
                            + status
                            + "\"}"
                    );

                }


                /* =========================
                   INSERT NEW RECORD
                   ========================= */

                else {

                    try (
                        PreparedStatement insertPs =
                                con.prepareStatement(insertSql)
                    ) {

                        insertPs.setInt(
                                1,
                                studentId
                        );

                        insertPs.setInt(
                                2,
                                subjectId
                        );

                        insertPs.setInt(
                                3,
                                totalClasses
                        );

                        insertPs.setInt(
                                4,
                                attendedClasses
                        );

                        insertPs.setString(
                                5,
                                attendanceDate
                        );

                        insertPs.executeUpdate();
                    }


                    out.print(
                            "{\"success\":true,"
                            + "\"message\":\"Attendance saved successfully\","
                            + "\"status\":\""
                            + status
                            + "\"}"
                    );
                }
            }


        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            out.print(
                    "{\"success\":false,"
                    + "\"message\":\"Database error while saving attendance\"}"
            );
        }
    }


    /* =========================
       EMPTY CHECK
       ========================= */

    private boolean isEmpty(String value) {

        return value == null
                || value.trim().isEmpty();
    }
}