import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FacultyMarkServlet")
public class FacultyMarkServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DB_URL =
        "jdbc:mysql://localhost:3306/smartattendance"
        + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root123";

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {

            HttpSession session = request.getSession(false);

            if (session == null ||
                session.getAttribute("userId") == null) {

                send(response, false, "Please login first.");
                return;
            }

            String studentId = request.getParameter("studentId");
            String subjectId = request.getParameter("subjectId");
            String examType = request.getParameter("examType");
            String marksValue = request.getParameter("marks");

            if (isEmpty(studentId) ||
                isEmpty(subjectId) ||
                isEmpty(examType) ||
                isEmpty(marksValue)) {

                send(response, false, "All fields are required.");
                return;
            }

            int student;
            int subject;
            double marks;

            try {
                student = Integer.parseInt(studentId);
                subject = Integer.parseInt(subjectId);
                marks = Double.parseDouble(marksValue);
            } catch (NumberFormatException e) {
                send(response, false,
                    "Invalid student, subject or marks.");
                return;
            }

            if (student <= 0 || subject <= 0) {
                send(response, false,
                    "Invalid student or subject.");
                return;
            }

            double maximum;

            if ("Mid 1".equalsIgnoreCase(examType) ||
                "Mid 2".equalsIgnoreCase(examType)) {

                maximum = 15;

            } else if ("Semester".equalsIgnoreCase(examType)) {

                maximum = 70;

            } else {

                send(response, false,
                    "Invalid examination. Use Mid 1, Mid 2 or Semester.");
                return;
            }

            if (marks < 0 || marks > maximum) {

                send(response, false,
                    "Marks for " + examType +
                    " must be between 0 and " + maximum + ".");
                return;
            }

            try (Connection con = getConnection()) {

                String checkSql =
                    "SELECT id FROM marks " +
                    "WHERE student_id=? AND subject_id=? AND exam_type=?";

                Integer existingId = null;

                try (PreparedStatement ps =
                        con.prepareStatement(checkSql)) {

                    ps.setInt(1, student);
                    ps.setInt(2, subject);
                    ps.setString(3, examType.trim());

                    try (ResultSet rs = ps.executeQuery()) {

                        if (rs.next()) {
                            existingId = rs.getInt("id");
                        }
                    }
                }

                if (existingId != null) {

                    String updateSql =
                        "UPDATE marks SET marks=? WHERE id=?";

                    try (PreparedStatement ps =
                            con.prepareStatement(updateSql)) {

                        ps.setDouble(1, marks);
                        ps.setInt(2, existingId);

                        ps.executeUpdate();
                    }

                    send(response, true,
                        "Marks updated successfully.");

                } else {

                    String insertSql =
                        "INSERT INTO marks " +
                        "(student_id, subject_id, marks, exam_type) " +
                        "VALUES (?, ?, ?, ?)";

                    try (PreparedStatement ps =
                            con.prepareStatement(insertSql)) {

                        ps.setInt(1, student);
                        ps.setInt(2, subject);
                        ps.setDouble(3, marks);
                        ps.setString(4, examType.trim());

                        ps.executeUpdate();
                    }

                    send(response, true,
                        "Marks saved successfully.");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(500);

            send(response, false,
                e.getMessage() == null
                    ? "Database error."
                    : e.getMessage());
        }
    }

    private void send(
            HttpServletResponse response,
            boolean success,
            String message)
            throws IOException {

        response.getWriter().print(
            "{\"success\":" + success +
            ",\"message\":\"" +
            escape(message) +
            "\"}"
        );
    }

    private boolean isEmpty(String value) {
        return value == null ||
               value.trim().isEmpty();
    }

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r");
    }
}