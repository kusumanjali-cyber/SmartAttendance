
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String path = req.getRequestURI()
                .substring(req.getContextPath().length());

        HttpSession session = req.getSession(false);

        if (path.equals("/login.html")
                || path.equals("/LoginServlet")
                || path.equals("/")
                || path.endsWith(".css")
                || path.endsWith(".js")) {

            chain.doFilter(request, response);
            return;
        }

        if (session == null
                || session.getAttribute("databaseRole") == null) {

            res.sendRedirect(req.getContextPath() + "/login.html");
            return;
        }

        String role = (String) session.getAttribute("databaseRole");

        if (path.startsWith("/admin")
                && !role.equals("admin")) {
            res.sendError(403, "Access Denied");
            return;
        }

        if (path.startsWith("/faculty")
                && !role.equals("faculty")) {
            res.sendError(403, "Access Denied");
            return;
        }

        if (path.startsWith("/student")
                && !role.equals("student")) {
            res.sendError(403, "Access Denied");
            return;
        }

        chain.doFilter(request, response);
    }
}