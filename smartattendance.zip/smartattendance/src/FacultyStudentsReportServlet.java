import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FacultyStudentsReportServlet")
public class FacultyStudentsReportServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String DB_URL =
        "jdbc:mysql://localhost:3306/smartattendance"
        + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root123";

    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            DB_URL,
            DB_USER,
            DB_PASSWORD
        );
    }

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null ||
            session.getAttribute("userId") == null) {

            sendError(response, "Please login first.");
            return;
        }

        /*
         * MARK STRUCTURE
         *
         * Mid 1    = 15
         * Mid 2    = 15
         * Semester = 70
         *
         * Only exams that have marks entered are included.
         */

        String sql =
            "SELECT " +
            "s.id, " +
            "s.student_name, " +
            "s.roll_number, " +
            "s.email, " +

            "COALESCE(a.total_classes, 0) AS total_classes, " +
            "COALESCE(a.attended_classes, 0) AS attended_classes, " +

            "COALESCE(m.total_marks, 0) AS total_marks, " +
            "COALESCE(m.maximum_marks, 0) AS maximum_marks " +

            "FROM students s " +

            "LEFT JOIN ( " +
            "SELECT student_id, " +
            "SUM(total_classes) AS total_classes, " +
            "SUM(attended_classes) AS attended_classes " +
            "FROM attendance_records " +
            "GROUP BY student_id " +
            ") a ON a.student_id = s.id " +

            "LEFT JOIN ( " +
            "SELECT " +
            "student_id, " +
            "SUM(marks) AS total_marks, " +
            "SUM( " +
            "CASE " +
            "WHEN LOWER(TRIM(exam_type)) = 'mid 1' THEN 15 " +
            "WHEN LOWER(TRIM(exam_type)) = 'mid 2' THEN 15 " +
            "WHEN LOWER(TRIM(exam_type)) = 'semester' THEN 70 " +
            "ELSE 0 " +
            "END " +
            ") AS maximum_marks " +
            "FROM marks " +
            "WHERE LOWER(TRIM(exam_type)) IN " +
            "('mid 1', 'mid 2', 'semester') " +
            "GROUP BY student_id " +
            ") m ON m.student_id = s.id " +

            "ORDER BY s.student_name";

        StringBuilder json = new StringBuilder();

        json.append("{\"success\":true,\"students\":[");

        boolean first = true;

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                int id = rs.getInt("id");

                String name = rs.getString("student_name");
                String rollNumber = rs.getString("roll_number");
                String email = rs.getString("email");

                int totalClasses =
                    rs.getInt("total_classes");

                int attendedClasses =
                    rs.getInt("attended_classes");

                double totalMarks =
                    rs.getDouble("total_marks");

                double maximumMarks =
                    rs.getDouble("maximum_marks");

                double attendancePercentage = 0;

                if (totalClasses > 0) {
                    attendancePercentage =
                        ((double) attendedClasses /
                         totalClasses) * 100;
                }

                double marksPercentage = 0;

                if (maximumMarks > 0) {
                    marksPercentage =
                        (totalMarks / maximumMarks) * 100;
                }

                int absentClasses =
                    totalClasses - attendedClasses;

                if (!first) {
                    json.append(",");
                }

                first = false;

                json.append("{");

                json.append("\"id\":")
                    .append(id)
                    .append(",");

                json.append("\"name\":\"")
                    .append(escape(name))
                    .append("\",");

                json.append("\"rollNumber\":\"")
                    .append(escape(rollNumber))
                    .append("\",");

                json.append("\"username\":\"")
                    .append(escape(email))
                    .append("\",");

                json.append("\"email\":\"")
                    .append(escape(email))
                    .append("\",");

                json.append("\"totalClasses\":")
                    .append(totalClasses)
                    .append(",");

                json.append("\"present\":")
                    .append(attendedClasses)
                    .append(",");

                json.append("\"attended\":")
                    .append(attendedClasses)
                    .append(",");

                json.append("\"absent\":")
                    .append(absentClasses)
                    .append(",");

                json.append("\"attendancePercentage\":")
                    .append(round(attendancePercentage))
                    .append(",");

                /*
                 * Keep the actual marks visible.
                 * Example: Mid 1 = 15
                 */
                json.append("\"marks\":")
                    .append(round(totalMarks))
                    .append(",");

                /*
                 * Separate percentage for status calculation.
                 */
                json.append("\"marksPercentage\":")
                    .append(round(marksPercentage))
                    .append(",");

                json.append("\"maximumMarks\":")
                    .append(round(maximumMarks));

                json.append("}");
            }

            json.append("]}");

            response.getWriter().print(json.toString());

        } catch (Exception e) {

            e.printStackTrace();

            response.setStatus(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR
            );

            sendError(
                response,
                "Database error: " +
                (e.getMessage() == null
                    ? "Unknown error"
                    : e.getMessage())
            );
        }
    }

    private double round(double value) {
        return Math.round(value * 10.0) / 10.0;
    }

    private void sendError(HttpServletResponse response,
                           String message)
            throws IOException {

        response.getWriter().print(
            "{\"success\":false,\"message\":\"" +
            escape(message) +
            "\"}"
        );
    }

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r");
    }
}