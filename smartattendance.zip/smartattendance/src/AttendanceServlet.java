import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AttendanceServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Minimum attendance percentage required to attend exams
    private static final double MIN_REQUIRED_PERCENTAGE = 75.0;

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String totalStr = request.getParameter("total");
        String attendedStr = request.getParameter("attended");

        response.setContentType("text/html;charset=UTF-8");

        try {

            int total = Integer.parseInt(totalStr);
            int attended = Integer.parseInt(attendedStr);

            if (total <= 0 || attended < 0 || attended > total) {

                response.getWriter().println(
                    "<h2>Invalid Attendance Values</h2>"
                );

                response.getWriter().println(
                    "<p>Please enter valid attendance details.</p>"
                );

                response.getWriter().println(
                    "<a href='home.html'>Go Back</a>"
                );

                return;
            }

            double percentage =
                    ((double) attended / total) * 100;

            percentage =
                    Math.round(percentage * 100.0) / 100.0;

            // ---- NEW: 75% check ----
            boolean isEligible = percentage >= MIN_REQUIRED_PERCENTAGE;

            String statusColor = isEligible ? "#16a34a" : "#dc2626";
            String statusBg = isEligible ? "#dcfce7" : "#fee2e2";
            String statusIcon = isEligible ? "✅" : "⚠️";
            String statusText = isEligible
                    ? "Eligible for exams (75% required)"
                    : "NOT eligible for exams — below 75% requirement";

            double classesNeeded = 0;
            if (!isEligible) {
                // How many more classes (in a row) needed to reach 75%
                // (attended + x) / (total + x) = 0.75  => x = (0.75*total - attended) / 0.25
                classesNeeded = Math.ceil(
                        (MIN_REQUIRED_PERCENTAGE / 100.0 * total - attended)
                        / (1 - MIN_REQUIRED_PERCENTAGE / 100.0)
                );
            }

            response.getWriter().println("<!DOCTYPE html>");
            response.getWriter().println("<html lang='en'>");
            response.getWriter().println("<head>");
            response.getWriter().println("<meta charset='UTF-8'>");
            response.getWriter().println(
                "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
            );
            response.getWriter().println("<title>Attendance Result</title>");

            response.getWriter().println(
                "<style>" +

                "*{box-sizing:border-box;}" +

                "body{" +
                "margin:0;" +
                "font-family:Arial,sans-serif;" +
                "background:linear-gradient(135deg,#eef5ff,#f5f0ff);" +
                "color:#172554;" +
                "display:flex;" +
                "justify-content:center;" +
                "align-items:center;" +
                "min-height:100vh;" +
                "}" +

                ".card{" +
                "background:white;" +
                "width:600px;" +
                "max-width:90%;" +
                "padding:40px;" +
                "border-radius:22px;" +
                "text-align:center;" +
                "box-shadow:0 15px 35px rgba(0,0,0,0.15);" +
                "}" +

                ".icon{" +
                "font-size:60px;" +
                "}" +

                "h1{" +
                "color:#4f46e5;" +
                "}" +

                ".percentage{" +
                "font-size:55px;" +
                "font-weight:bold;" +
                "color:#0969d5;" +
                "margin:25px;" +
                "}" +

                ".status{" +
                "padding:12px 18px;" +
                "border-radius:12px;" +
                "font-weight:bold;" +
                "font-size:16px;" +
                "margin:10px 0 20px;" +
                "}" +

                ".details{" +
                "font-size:20px;" +
                "color:#64748b;" +
                "line-height:2;" +
                "}" +

                ".needed{" +
                "font-size:15px;" +
                "color:#dc2626;" +
                "margin-top:10px;" +
                "}" +

                "button{" +
                "padding:14px 25px;" +
                "border:none;" +
                "border-radius:10px;" +
                "background:linear-gradient(90deg,#4f46e5,#9333ea);" +
                "color:white;" +
                "font-size:16px;" +
                "font-weight:bold;" +
                "cursor:pointer;" +
                "margin-top:20px;" +
                "}" +

                "</style>"
            );

            response.getWriter().println("</head>");
            response.getWriter().println("<body>");
            response.getWriter().println("<div class='card'>");
            response.getWriter().println("<div class='icon'>📊</div>");
            response.getWriter().println("<h1>SMART ATTENDANCE</h1>");
            response.getWriter().println("<p>Attendance Calculation Result</p>");

            response.getWriter().println(
                "<div class='percentage'>" + percentage + "%</div>"
            );

            // ---- NEW: status badge ----
            response.getWriter().println(
                "<div class='status' style='background:" + statusBg +
                ";color:" + statusColor + ";'>" +
                statusIcon + " " + statusText +
                "</div>"
            );

            response.getWriter().println(
                "<div class='details'>" +

                "Total Classes: <strong>" + total + "</strong><br>" +

                "Attended Classes: <strong>" + attended + "</strong><br>" +

                "Absent Classes: <strong>" + (total - attended) + "</strong><br>" +

                "Attendance Percentage: <strong>" + percentage + "%</strong>" +

                "</div>"
            );

            // ---- NEW: how many classes needed to become eligible ----
            if (!isEligible) {
                response.getWriter().println(
                    "<div class='needed'>You need to attend the next <strong>" +
                    (int) classesNeeded +
                    "</strong> class(es) continuously to reach 75%.</div>"
                );
            }

            response.getWriter().println(
                "<button onclick=\"location.href='home.html'\">Calculate Again</button>"
            );

            response.getWriter().println("<br>");

            response.getWriter().println(
                "<button onclick=\"location.href='index.html'\">Back to Home</button>"
            );

            response.getWriter().println("</div>");
            response.getWriter().println("</body>");
            response.getWriter().println("</html>");

        } catch (NumberFormatException e) {

            response.getWriter().println("<h2>❌ Invalid Input</h2>");
            response.getWriter().println("<p>Please enter numbers only.</p>");
            response.getWriter().println("<a href='home.html'>Try Again</a>");
        }
    }
}